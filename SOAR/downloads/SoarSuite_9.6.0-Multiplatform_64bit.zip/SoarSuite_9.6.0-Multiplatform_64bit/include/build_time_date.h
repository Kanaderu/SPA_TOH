const char* kTimestamp = __TIME__;
const char* kDatestamp = __DATE__;
//* Last build of Soar 9.6.0 occurred at Thu Jul 27 14:30:22 2017 *//
